//
// CS300 Project 2
// ABCU University Advising Assistance Software
// Author : Matthew Muller
//


#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <sstream>
#include <vector>
using namespace std;


// Define structure to hold Course information
struct Course {
    //Declare strings for course name and number
    string courseName, courseNumber;
    
    //Declare vector of strings to hold prerequisites
    vector<string> prerequisites;
};


// Internal structure for tree node
struct Node {
    //Course Object
    Course course;

    //Declare pointers to node's children
    Node* left;
    Node* right;

    //Default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    //Initialize with course
    Node(Course aCourse) : Node() {
        this->course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;

    

public:
    BinarySearchTree();
    void printCourses();
    void courseInfo(string courseNumber);
    void Insert(Course course);
    void addNode(Node* node, Course course);
    void inOrder(Node* node);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    //root is equal to nullptr
    root = nullptr;
}

/*
* Function for looking up a course by
* its course number and printing out
* its name and prerequisites
*/
void BinarySearchTree::courseInfo(string courseNumber) {
    //Start at root
    Node* current = root;
    //Loop through bst until matching course number is found
    while (current != nullptr) {
        // if match found, return current bid
        if (current->course.courseNumber.compare(courseNumber) == 0) {
            cout << courseNumber << ", " << current->course.courseName << endl;
            cout << "Prerequisites: ";
            for (int i = 0; i < current->course.prerequisites.size(); ++i) {
                cout << current->course.prerequisites.at(i) << " ";
            }
        }
        // if bid is smaller than current node then traverse left
        else if (courseNumber.compare(current->course.courseNumber) < 0) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
        
        
    }
}

void BinarySearchTree::inOrder(Node* node) {
    //if node is not equal to null ptr
    if (node != nullptr) {
        //InOrder not left
        this->inOrder(node->left);
        //output bidID, title, amount, fund
        cout << node->course.courseNumber << ", " << node->course.courseName << endl;
        //InOder right
        this->inOrder(node->right);
    }
}

/*
* Function for printing a list of all
* courses in alphanumeric order
*/
void BinarySearchTree::printCourses() {
    
}

/*
* Function for adding a node to the bst
*/
void BinarySearchTree::addNode(Node* node, Course course) {
    // if node is larger then add to left
    if (node->course.courseNumber.compare(course.courseNumber) > 0) {
        // if no left node
        if (node->left == nullptr) {
            // this node becomes left
            node->left = new Node(course);
        }
        // else recurse down the left node
        else {
            this->addNode(node->left, course);
        }
    }
    else {
        // else
        // if no right node
        if (node->right == nullptr) {
            // this node becomes right
            node->right = new Node(course);
        }
        else {
            //else
                // recurse down the left node
            this->addNode(node->right, course);
        }
    }
}

/*
* Function for inserting a course into bst
*/
void BinarySearchTree::Insert(Course course) {
    //if root equarl to null ptr
    if (root == nullptr) {
        // root is equal to new node bid
        root = new Node(course);
    }
    // else
    else {
        // add Node root and bid
        this->addNode(root, course);
    }
}


/*
* Function for reading csv file and storing 
* class objects in Binary Search Tree
* @param path to file
*/
void readFile(string csvPath, BinarySearchTree* bst) {
    //Declare file object of type fstream
    fstream fin;
    //Open csv file for reading
    fin.open(csvPath, ios::in);

    string line;
    Course course;
    //If file is open
    if (fin.is_open()) {
        //Loop through file until eof is reached
        while (!fin.eof()) {
            string line;
            Course course;
            getline(fin, course.courseNumber, ',');
            getline(fin, course.courseName, ',');
            getline(fin, line);
            stringstream ss(line);
            string temp;
            ss >> temp;
            course.prerequisites.push_back(temp);
            Node* node;
            bst->addNode(node, course);
            bst->Insert(course);
        }

    }
}


int main()
{
    string csvPath, fileChoice;
    BinarySearchTree* bst;

    cout << "Would You Like to Enter a File Name or Use the Default File?" << endl << "Press 1 to Enter File Name or 2 to Use Default File" << endl;
    cin >> fileChoice;

    while (fileChoice != "1" && fileChoice != "2") {
        cout << "Please enter either 1 or 2" << endl;
        cin >> fileChoice;
    }
    if (fileChoice == "1") {
        cout << "Please enter File Path" << endl;
        cin >> csvPath;
    }
    else {
        cout << "Default File Chosen\n" << endl;
        csvPath == "C:\\Users\\mattm\\Downloads\\ABCU_Advising_Program_Input.txt";
    }

    string menuChoice = "";
    while (menuChoice != "d") {
        cout << "What would you like to do?" << endl;
        cout << "a. Load Data Structure." << endl;
        cout << "b. Print Course List." << endl;
        cout << "c. Print Course with specified Course Number." << endl;
        cout << "d. Exit" << endl;
        cin >> menuChoice;
        if (menuChoice == "a") {
            readFile(csvPath, bst);
        }
        else if (menuChoice == "b") {
            readFile(csvPath, bst);
            bst->printCourses();
        }
        else if (menuChoice == "c") {
            readFile(csvPath, bst);
            cout << "\nEnter Course Number: ";
            string courseNumber;
            cin >> courseNumber;
            bst->courseInfo(courseNumber);
        }
    }
}
